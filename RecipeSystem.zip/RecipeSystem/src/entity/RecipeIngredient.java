package entity;
/**
 * Represents the relation between recipe and ingredient
 * A recipe can have multiple ingredients, but not reversely.
 */
public class RecipeIngredient {
	int id;
	Recipe recipe;
	Ingredient ingredient;
	
	public void setId(int id) {
		  this.id = id;
		 }
		 
		 public void setIngredient(Ingredient ingredient) {
		  this.ingredient = ingredient;
		 }
		 
		 public void setRecipe(Recipe recipe) {
		  this.recipe = recipe;
		 }
		 
		 public int getId() {
		  return id;
		 }
		 
		 public Ingredient getIngredient() {
		  return ingredient;
		 }
		 
		 public Recipe getRecipe() {
		  return recipe;
		 }
}
