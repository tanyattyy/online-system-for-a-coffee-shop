package entity;
/**
 * Ingredient class
 */
public class Ingredient {
	int ingredientId;
	String ingredientName;
	
	public int getIngredientId() {
		return ingredientId;
	}
	
	public String getIngredientName() {
		return ingredientName;
	}

	public void setIngredientId(int ingredientId) {
		this.ingredientId = ingredientId;
	}

	public void setIngredientName(String ingredientName) {
		this.ingredientName = ingredientName;
	}

}
