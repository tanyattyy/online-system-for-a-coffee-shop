package entity;
/**
 * Recipe class
 */
public class Recipe {
	int recipeId;
	String recipeName;
	
	public int getRecipeId() {
		return recipeId;
	}
	
	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeId(int recipeId) {
		this.recipeId = recipeId;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

}
