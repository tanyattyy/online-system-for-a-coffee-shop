package servlet;

import dao.IngredientDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
/**
 * Servlet for create new ingredient
 */
@WebServlet(name = "createIngredient", urlPatterns = {"/createIngredient"})
public class CreateIngredientServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       resp.sendRedirect("./createIngredient.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        IngredientDao dao = new IngredientDao();
        String ingredientName = req.getParameter("ingredientName");
        int newId = dao.createIngredient(ingredientName);
        if(newId == -1){
            req.setAttribute("createIngredientResult", "Create ingredient failed, duplicated name");
        }else{
            req.setAttribute("createIngredientResult", "Create ingredient success!");
        }
        req.getRequestDispatcher("./createIngredient.jsp").forward(req,resp);
    }
}
