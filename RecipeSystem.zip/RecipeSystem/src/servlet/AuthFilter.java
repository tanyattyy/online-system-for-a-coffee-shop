package servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Use this AuthFilter class to receive and filter all the incoming request from the browser
 * And only let the logged-in user to go through some certain pages.
 */
@WebFilter("/*")
public class AuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) {
    }
    /**
     * Filter all the incoming HTTP request to let some pass and redirect others to login page, based
     * on the user login status.
     * @param servletRequest
     * @param servletResponse
     * @param filterChain
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) servletRequest;
        HttpServletResponse resp = (HttpServletResponse) servletResponse;
        String url = req.getRequestURI();
        // if is logged in, or some other web pages that do not need to login to view, let this request pass
        if (req.getSession().getAttribute("user") != null ||
                url.contains("/login") ||
                url.equals("/") ||
                url.contains("/signup") ||
                url.contains("resource") ||
                url.contains("/report.jsp")) {
            filterChain.doFilter(servletRequest, servletResponse);
        } else {
            // Otherwise, redirect the browser to login page.
            resp.sendRedirect(req.getContextPath() + "/login");
        }
    }

    @Override
    public void destroy() {
    }
}
