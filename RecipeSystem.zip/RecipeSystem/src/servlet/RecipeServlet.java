package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.RecipeDao;
import dao.RecipeIngredientDao;
import entity.Recipe;
import entity.RecipeIngredient;
/**
 * Servlet for displaying recipe - ingredient details
 */
@WebServlet(name = "recipe", urlPatterns = { "/recipe" })
public class RecipeServlet extends HttpServlet {

	//TODO load data from the database
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	   // Use a hashmap to represent the relation between a recipe and its ingredients
	   Map<String, List<String>> rIMap = new HashMap<>();

	   // get data from the recipeIngredient dao class
	   RecipeIngredientDao rIDao = new RecipeIngredientDao();
	   List<RecipeIngredient> data = rIDao.getData();

	   // Use for-loop to get all the recipe names and the corresponding ingredient names.
	   for(RecipeIngredient rI : data){
	      // if the hashmap does not have this recipe name, we fill that name as a new key,
	      // and then create a new list of ingredients as the value, then add the ingredient name
	      // in the list.
	      if(!rIMap.containsKey(rI.getRecipe().getRecipeName())){
	         List<String> ingredientList = new ArrayList<>();
	         ingredientList.add(rI.getIngredient().getIngredientName());
	         rIMap.put(rI.getRecipe().getRecipeName(), ingredientList);
	      }else{
	         // if the hashmap already have the recipe name, we take out the corresponding ingredient
	         // list and add a new item of ingredient, and add it back to this hashmap.
	         List<String> ingredientList = rIMap.get(rI.getRecipe().getRecipeName());
	         ingredientList.add(rI.getIngredient().getIngredientName());
	         rIMap.put(rI.getRecipe().getRecipeName(), ingredientList);
	      }
	   }

	   // pass the hashmap to the request, then forward this request.
	   req.setAttribute("rIMap", rIMap);

	   req.getRequestDispatcher("./recipe.jsp").forward(req, resp);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException{
		//TODO 以后要写recipe网页的一些数据请求
		
	}
}
