package servlet;

import dao.IngredientDao;
import dao.RecipeDao;
import dao.RecipeIngredientDao;
import entity.Ingredient;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/**
 * Servlet for display ingredient list and create new recipe based on the
 * selections of the ingredients.
 */
@WebServlet(name = "ingredient", urlPatterns = {"/ingredient"})
public class IngredientServlet extends HttpServlet {

    List<Ingredient> ingredientList = new ArrayList<>();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        IngredientDao ingredientDao = new IngredientDao();
        ingredientList = ingredientDao.getData();

        // pass the hashmap to the request, then forward this request.
        req.setAttribute("ingredientList", ingredientList);

        req.getRequestDispatcher("./ingredients.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        RecipeDao recipeDao = new RecipeDao();
        IngredientDao ingredientDao = new IngredientDao();
        RecipeIngredientDao rIDao = new RecipeIngredientDao();

        String newRecipeName = req.getParameter("recipeName");

        if(newRecipeName == null || newRecipeName.trim().length() == 0){
            req.setAttribute("createRecipeResult","create recipe failed, no recipe name!");
            req.setAttribute("ingredientList", ingredientList);
            req.getRequestDispatcher("./ingredients.jsp").forward(req, resp);
            return;
        }

        int recicpeId = recipeDao.createRecicpe(newRecipeName);
        int size = ingredientList.size();

        // Use this integer to calculate how many checkboxes are not selected
        // if 0 checkbox is ticked, then set error msg.
        int emptyCount = 0;

        try{
            for(int i = 0; i < size; i++){
                String key = "ingredient" + i;
                String ingredientId = req.getParameter(key);
                if(ingredientId != null){
                    int id = Integer.parseInt(ingredientId);
                    String ingredientName = ingredientDao.getIngredientName(id);
                    rIDao.addNewRI(recicpeId, newRecipeName, id, ingredientName);
                }else{
                    emptyCount++;
                }
            }

            if(emptyCount == size){
                req.setAttribute("createRecipeResult","create recipe failed, no ingredient selected!");
            }else{
                req.setAttribute("createRecipeResult","create recipe success!");
            }

            req.setAttribute("ingredientList", ingredientList);
            req.getRequestDispatcher("./ingredients.jsp").forward(req, resp);
        }catch (NumberFormatException e){
            System.out.println(e.toString());
        }
    }
}
