package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBConnection;
import entity.Recipe;

/**
 * Database actions for the recipe table
 */
public class RecipeDao extends DBConnection{

	/**
	 * Get all ingredients from the ingredient table
	 * @return
	 */	
	public List<Recipe> getData() {
		List<Recipe> list= new ArrayList<>();
		try {
			// acquire the database connection object from the father class
			Connection conn = super.getConnection();
            
			String sql = "SELECT * FROM RECIPES_TANYUN";

			// user prepared statement to be safe
			PreparedStatement pst = null;
			ResultSet rs = null;

			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			// use while loop to get all the recipes names
			while (rs.next()) {
				
				Recipe recipe = new Recipe();
				
				String recipeName = rs.getString("recipe_name");
				
				recipe.setRecipeName(recipeName);
				
				list.add(recipe);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * Create a new recipe
	 * @param recipeName name string of this new recipe
	 * @return id value of this new recipe
	 */
	public int createRecicpe(String recipeName){
		int recipeId = -1;
		try {
			// acquire the database connection object from the father class
			Connection conn = super.getConnection();

			String sql = "INSERT INTO RECIPES_TANYUN (RECIPE_NAME) VALUES (?)";

			// user prepared statement to be safe
			PreparedStatement pst = null;
			ResultSet rs = null;

			pst = conn.prepareStatement(sql);
			pst.setString(1, recipeName);
			pst.executeUpdate();

			sql = "SELECT * FROM RECIPES_TANYUN WHERE RECIPE_NAME = ?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, recipeName);
			rs = pst.executeQuery();

			// use while loop to get all the recipes names
			if (rs.next()) {
				recipeId = rs.getInt("recipe_id");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return recipeId;
	}
}
