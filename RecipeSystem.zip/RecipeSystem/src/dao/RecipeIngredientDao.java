package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBConnection;
import entity.Ingredient;
import entity.Recipe;
import entity.RecipeIngredient;
/**
 * Database actions for the ingredient table
 */
public class RecipeIngredientDao extends DBConnection {

	/**
	 * Get all data from the recipe_ingredient table
	 * This tables tells a recipe contains how many ingredients
	 * @return
	 */	
	public List<RecipeIngredient> getData() {
		List<RecipeIngredient> list= new ArrayList<>();
		try {
			// acquire the database connection object from the father class
			Connection conn = super.getConnection();

			String sql = "SELECT * FROM RECIPES_INGREDIENTS_TANYUN";

			// user prepared statement to be safe
			PreparedStatement pst = null;
			ResultSet rs = null;

			pst = conn.prepareStatement(sql);
			
			rs = pst.executeQuery();
			
			// use while loop to get all the results
			while (rs.next()) {
				RecipeIngredient riIngredient = new RecipeIngredient();
				Recipe recipe = new Recipe();
				Ingredient ingredient = new Ingredient();
				
				String recipeName = rs.getString("recipe_name");
				String ingredientName = rs.getString("ingredient_name");
				
				recipe.setRecipeName(recipeName);
				ingredient.setIngredientName(ingredientName);
				
				riIngredient.setRecipe(recipe);
				riIngredient.setIngredient(ingredient);
				
				list.add(riIngredient);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
	
	/**
	 * Add new recipe-ingredient relation into the database
	 * @param recipeId recipe's id to add
	 * @param recipeName recipe's name to add
	 * @param ingredientId ingredient's id
	 * @param ingredientName ingredient's name
	 */
	public void addNewRI(int recipeId, String recipeName, int ingredientId, String ingredientName){
		try {
			// acquire the database connection object from the father class
			Connection conn = super.getConnection();

			String sql = "INSERT INTO RECIPES_INGREDIENTS_TANYUN(RECIPE_ID, RECIPE_NAME, INGREDIENT_ID, INGREDIENT_NAME) " +
					"VALUES (?, ?, ?, ?)";

			// User prepared statement to be safe
			PreparedStatement pst = null;

			ResultSet rs = null;

			pst = conn.prepareStatement(sql);
			pst.setInt(1, recipeId);
			pst.setString(2, recipeName);
			pst.setInt(3, ingredientId);
			pst.setString(4, ingredientName);

			pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
