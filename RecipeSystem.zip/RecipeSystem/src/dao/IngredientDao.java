package dao;

import db.DBConnection;
import entity.Ingredient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
/**
 * Database actions for the ingredient table
 */
public class IngredientDao extends DBConnection {

    /**
     * Get all ingredients from the ingredient table
     * @return
     */
    public List<Ingredient> getData() {
        List<Ingredient> list = new ArrayList<>();
        try {
            // acquire the database connection object from the father class
            Connection conn = super.getConnection();

            String sql = "SELECT * FROM Ingredients_Tanyun";

            // user prepared statement to be safe
            PreparedStatement pst = null;
            ResultSet rs = null;

            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();

            // use while loop to get all the ingredients's name and id
            while (rs.next()) {

                Ingredient ingredient = new Ingredient();

                String ingredientName = rs.getString("ingredient_name");
                int ingredientId = rs.getInt("ingredient_id");
                
                ingredient.setIngredientId(ingredientId);
                ingredient.setIngredientName(ingredientName);

                list.add(ingredient);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    /**
     * Get a ingredient's name by its id
     * @param id
     * @return
     */
    public String getIngredientName(int id){
        String name = "";
        try {
            // acquire the database connection object from the father class
            Connection conn = super.getConnection();

            String sql = "SELECT * FROM Ingredients_Tanyun WHERE ingredient_id = ?";

            // user prepared statement to be safe
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = null;

            rs = pst.executeQuery();

            // use while loop to get all the recipes names
            if (rs.next()) {
                name = rs.getString("ingredient_name");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return name;
    }

    /**
     * Create a new ingredient inside the database
     * and return its id
     * if it is default -1, then we know this create action failed to create a
     * new row in this data table.
     * @param ingredientName
     * @return new data row's id
     */
    public int createIngredient(String ingredientName){
        int id = -1;
        try {
            // acquire the database connection object from the father class
            Connection conn = super.getConnection();

            String sql = "INSERT INTO Ingredients_Tanyun (ingredient_name) VALUES (?)";

            // user prepared statement to be safe
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, ingredientName);


            int newRows = pst.executeUpdate();

            // if newRows is 1, it means that the above update execution has created a new row.
            if (newRows == 1) {
                // get this new row's id and then return.
                ResultSet rs = null;
                sql = "SELECT * FROM Ingredients_Tanyun WHERE ingredient_name = ?";
                pst = conn.prepareStatement(sql);
                pst.setString(1, ingredientName);
                rs = pst.executeQuery();
                if(rs.next()){
                    id = rs.getInt("ingredient_id");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return id;
    }
}
