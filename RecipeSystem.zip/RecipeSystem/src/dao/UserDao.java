package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import db.DBConnection;
import entity.User;
/**
 * Database actions for the user table
 */
public class UserDao extends DBConnection {

	/**
	 * Check if this username-password combination of User object parameter is valid
	 * @param u The User object constructed by the user's input
	 * @return if the login is success or not.
	 */
	public boolean login(User u) {
		try {
			// acquire the database connection object from the father class
			Connection conn = super.getConnection();

			String sql = "SELECT USERNAME,PASSWORD FROM USERS_TANYUN WHERE USERNAME=?";

			// user prepared statement to be safe
			PreparedStatement pst = null;
			ResultSet rs = null;

			pst = conn.prepareStatement(sql);
			pst.setString(1, u.getUsername());
			rs = pst.executeQuery();

			// if result set has some values
			if (rs.next()) {
				if (u.getPassword().equals(rs.getString("PASSWORD"))) {
					u.setUsername(rs.getString("USERNAME"));
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean signUp(User u) {
		try {
			// acquire the database connection object from the father class
			Connection conn = super.getConnection();
			
			//use prepared statement to be safe, it allows you to set the parameters
			//to replace the ? inside the sql string above
			PreparedStatement pst = null;
			String sqlCheck = "SELECT USERNAME FROM USERS_TANYUN WHERE USERNAME=?";
			ResultSet rs = null;
			pst = conn.prepareStatement(sqlCheck);
			pst.setString(1, u.getUsername());
			rs = pst.executeQuery();
			
			//if there is an user that has the same username , then we do not allow signup action
			if(rs.next()) {
				return false;
			}

			//insert new data into USERS_TANYUN table
			String sql = "INSERT INTO USERS_TANYUN (USERNAME, PASSWORD) VALUES(?, ?)";
			
			int result = 0;

			pst = conn.prepareStatement(sql);
			pst.setString(1, u.getUsername());
			pst.setString(2, u.getPassword());
			result = pst.executeUpdate();
			if(result==1) {
					return true;
				}else {
					return false;
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
