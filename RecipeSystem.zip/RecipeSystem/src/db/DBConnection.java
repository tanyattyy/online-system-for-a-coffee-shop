package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * Class for handling the database information and connection to it
 */
public class DBConnection {
	
	 //the driver class for the given oracle database 
	 private static final String driver = "oracle.jdbc.driver.OracleDriver"; 
	 
	 //the URL and credential to connect to the online database 
	 private static final String url = "jdbc:oracle:thin:@ee417.c7clh2c6565n.eu-west-1.rds.amazonaws.com:1521:EE417";
	 private static final String username = "ee_user";//the username of this database 
	 private static final String password = "ee_pass";// the password of this database

	 //the object to connect to the database
	 private static Connection conn = null;

	 //use this static code block to load the JDBC driver 
	 static {
	  try {
	   Class.forName(driver);
	  } catch (Exception ex) {
	   ex.printStackTrace();
	  }
	 }

	 //return the connection object 
	 public static Connection getConnection() throws Exception {
	  if (conn == null) {
	   conn = DriverManager.getConnection(url, username, password);
	   return conn;
	  }
	  return conn;
	 }
}

		/*
		 * //close the connection to the database public static void close(Connection
		 * conn, Statement st, ResultSet rs) { try { if (conn != null) conn.close(); if
		 * (st != null) st.close(); if (rs != null) rs.close(); } catch (SQLException e)
		 * { e.printStackTrace(); }
		 * 
		 * }
		 * 
		 * // execute the given parameter sql statement public static boolean
		 * executeSql(String sql) { Connection conn = null; try { conn =
		 * getConnection(); } catch (Exception e) { e.printStackTrace(); } Statement st
		 * = null; try { st = conn.createStatement(); return st.executeUpdate(sql) > 0;
		 * } catch (SQLException e) { e.printStackTrace(); } finally { close(conn, st,
		 * null); } return false; } }
		 */
